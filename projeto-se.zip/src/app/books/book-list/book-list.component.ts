import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { BookService } from '../../services/books.service';
import { BooksModule } from '../books.module';

@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css'],
})
export class BookListngComponent implements OnInit {
  books: any[] = [];
  bookForm!: FormGroup; // Define the bookForm as a FormGroup

  constructor(private bookService: BookService) {}

  ngOnInit(): void {
    this.loadBooks();

    // Initialize the book form with form controls
    this.bookForm = new FormGroup({
      title: new FormControl('', Validators.required), // Title is required
      author: new FormControl('', Validators.required), // Author is required
      coverImage: new FormControl('', Validators.required), // Cover Image is required
    });
  }

  // Load existing books from the service
  loadBooks(): void {
    this.books = this.bookService.getBooks();
  }

  // Add a book using form values
  addBook(): void {
    if (this.bookForm.valid) {
      const newBook = {
        id: this.books.length + 1,
        title: this.bookForm.get('title')?.value, // Get value from form control
        author: this.bookForm.get('author')?.value,
        coverImage: this.bookForm.get('coverImage')?.value,
      };

      this.bookService.addBook(newBook);
      this.loadBooks();

      // Reset the form after submission
      this.bookForm.reset();
    }
  }

  // Update a book's information
  updateBook(
    id: number,
    title: string,
    author: string,
    coverImage: string
  ): void {
    const updatedBook = { id, title, author, coverImage };
    this.bookService.updateBook(id, updatedBook);
    this.loadBooks();
  }

  // Delete a book from the list
  deleteBook(id: number): void {
    this.bookService.deleteBook(id);
    this.loadBooks();
  }
}
