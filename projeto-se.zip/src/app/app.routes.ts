import { Routes } from '@angular/router';
import { AppComponent } from './app.component'; // Assuming this is your main component
import { BookListngComponent } from './books/book-list/book-list.component';
import { LoginComponent } from './login/login.component';

export const routes: Routes = [
  { path: '', component: AppComponent },
  { path: 'login', component: LoginComponent },
  { path: 'dashboard', component: BookListngComponent },
  { path: '**', redirectTo: '', pathMatch: 'full' },
];
